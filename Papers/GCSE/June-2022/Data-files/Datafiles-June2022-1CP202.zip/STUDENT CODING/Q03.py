# -------------------------------------------------------------------
# Import libraries
# -------------------------------------------------------------------
# =====> Add a line to import the math library


# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------
squareArea = 0
excessArea = 0.0
side = 0
radius = 0
diameter = 0

# =====> Set the variable with a value of the correct data type
#        for the area of the circle
circleArea =

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------
side = int (input ("Enter the length of a side for the square: "))
radius = int (input ("Enter the radius of the circle: "))

# =====> Add a line to calculate the diameter of the circle


# =====> Complete the selection statement to check that circle
#        will fit inside the square
if (                      ):
    print ("Invalid input")
else:
    # =====> Add a line to calculate the area of the outside square


    # =====> Add a line to calculate the area of the circle using
    #        exponentiation, i.e. raising a number to a power


    # =====> Add a line to calculate the area of excess card


    print ("Excess area is ", excessArea)
