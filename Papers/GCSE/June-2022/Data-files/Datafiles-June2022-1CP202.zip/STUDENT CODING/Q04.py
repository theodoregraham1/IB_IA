# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------
layout = "{} is {}"
binary = ""
denary = 0

# -------------------------------------------------------------------
# Subprograms
# -------------------------------------------------------------------
def binaryLoop (pBinary):
# =====> Rearrange the mixed up lines
        total = total + value
    for index in range (len (pBinary) - 1, -1, -1):
    total = 0
        digit = pBinary[index]
    return (total)
    value = 0
    multiplier = 1

        value = multiplier * int (digit)
    digit = ""
        multiplier = multiplier * 2
# End of mixed up lines

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------
# =====> Rearrange the mixed up lines
    binary = input ("Enter a binary number (empty to exit): ")
binary = input ("Enter a binary pattern (empty to exit): ")
    denary = binaryLoop (binary)
    print (layout.format (binary, denary))
while (binary != ""):
# End of mixed up lines

